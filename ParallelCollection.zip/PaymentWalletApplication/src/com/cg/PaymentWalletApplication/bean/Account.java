package com.cg.PaymentWalletApplication.bean;

import java.util.ArrayList;

//1.create account
//2.show balance
//3.deposit
//4.withdraw
//5.print transactions

public class Account {
	private static String bankname = "HDFC BANK";
	private String name;
	private String address;
	private double aadharCard;
	private long phoneNumber;
	private long accountNumber;
	private double initialBalance;

	private ArrayList<Transaction> transactions = new ArrayList<>();

	public static String getBankname() {
		return bankname;
	}

	public static void setBankname(String bankname) {
		Account.bankname = bankname;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	public double getAadharCard() {
		return aadharCard;
	}

	public void setAadharCard(double aadharCard) {
		this.aadharCard = aadharCard;
	}

	public long getPhoneNumber() {
		return phoneNumber;
	}

	public void setPhoneNumber(long phoneNumber) {
		this.phoneNumber = phoneNumber;
	}

	public long getAccountNumber() {
		return accountNumber;
	}

	public void setAccountNumber(long accountNumber) {
		this.accountNumber = accountNumber;
	}

	public double getInitialBalance() {
		return initialBalance;
	}

	public void setInitialBalance(double initialBalance) {
		this.initialBalance = initialBalance;
	}

	public ArrayList<Transaction> getTransactions() {
		return transactions;
	}

	public void setTransactions(Transaction transactions) { // imp
		this.transactions.add(transactions);
	}

	@Override
	public String toString() {
		return "Account [name=" + name + ", address=" + address + ", aadharCard=" + aadharCard + ", phoneNumber="
				+ phoneNumber + ", accountNumber=" + accountNumber + ", initialBalance=" + initialBalance
				+ ", transactions=" + transactions + "]";
	}

}
