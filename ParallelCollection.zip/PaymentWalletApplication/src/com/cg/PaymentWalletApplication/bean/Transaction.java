package com.cg.PaymentWalletApplication.bean;

import java.time.LocalDateTime;

public class Transaction {
	private double amount;
	private String type;//d or c
	private LocalDateTime date;
	private double Balance;
	
	public double getAmount() {
		return amount;
	}
	public void setAmount(double amount) {
		this.amount = amount;
	}
	public LocalDateTime getDate() {
		return date;
	}
	public void setDate(LocalDateTime date) {
		this.date = date;
	}
	
	
	public String getType() {
		return type;
	}
	public void setType(String type) {
		this.type = type;
	}

	public double getBalance() {
		return Balance;
	}
	public void setBalance(double balance) {
		Balance = balance;
	}
	
	@Override
	public String toString() {
		return "Transaction [amount=" + amount + ", type=" + type + ", date and time=" + date + ", Balance=" + Balance + "]";
	}
	
	
	
}
