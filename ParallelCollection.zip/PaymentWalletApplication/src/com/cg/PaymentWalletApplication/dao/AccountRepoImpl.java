package com.cg.PaymentWalletApplication.dao;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;

import com.cg.PaymentWalletApplication.bean.Account;
import com.cg.PaymentWalletApplication.bean.Transaction;

public class AccountRepoImpl implements IAccountRepo {
	Map<Long,Account> bank = new HashMap<>(); 
	

	@Override
	public void addAccount(Account a) {
		bank.put(a.getAccountNumber(), a);
		
	}

	@Override
	public void showBalance(long accountNumber) {
	System.out.println((bank.get(accountNumber).getInitialBalance()));
		
	}

	@Override
	public void deposit(long accountNumber,double amount) {
		Account acc = bank.get(accountNumber);
		double b = acc.getInitialBalance();
		acc.setInitialBalance(b+amount);
		
		Transaction t = new Transaction();
		t.setAmount(amount);
		t.setType("Credited..");
		t.setDate(LocalDateTime.now());
		t.setBalance(b+amount);
		acc.setTransactions(t);


	}
	
	@Override
	public void fundTransfer(long accountNumber, long accountNumber2,double amount) {
		withdraw(accountNumber, amount);
		deposit(accountNumber2, amount);
		
	}
	
	@Override
	public void withdraw(long accountNumber,double amount) {
		Account acc = bank.get(accountNumber);
		double b = acc.getInitialBalance();
		acc.setInitialBalance(b-amount);
		
		Transaction t = new Transaction();
		t.setAmount(amount);
		t.setType("Debited..");
		t.setDate(LocalDateTime.now());
		t.setBalance(b-amount);
		acc.setTransactions(t);
		
	}

	@Override
	public void showTransactions(long accountNumber) {
		ArrayList<Transaction> t = bank.get(accountNumber).getTransactions();
		Iterator<Transaction> itr = t.iterator(); 
		while(itr.hasNext()) {
			System.out.println(itr.next());
		}
		
	}
	
}
	