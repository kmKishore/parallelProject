package com.cg.PaymentWalletApplication.dao;

import com.cg.PaymentWalletApplication.bean.Account;


public interface IAccountRepo {

	void addAccount(Account a);
	void showBalance(long accountNumber);
	void deposit(long accountNumber,double amount);
	void withdraw(long accountNumber,double amount);
	void showTransactions(long accountNumber);
	void fundTransfer(long accountNumber,long accountNumber2, double amount);
	
}
