package com.cg.PaymentWalletApplication.ui;

import java.time.LocalDateTime;
import java.util.Scanner;

import com.cg.PaymentWalletApplication.bean.Account;
import com.cg.PaymentWalletApplication.bean.Transaction;
import com.cg.PaymentWalletApplication.service.AccountServiceImpl;

public class TestBank {
	public static void main(String[] args) {
		AccountServiceImpl ips = new AccountServiceImpl();
		 Scanner sc = new Scanner(System.in);
		 
		while(true) {
			System.out
			.println("Enter a choice: " + "\n1.Create Account" +  "\n2.Show Balance" + "\n3.Deposit" + "\n4.Withdraw" + "\n5.Print Transactions"
					+ "\n6.Fund transfer to someone"+ "\n7.exit");
		  
		   int opt = sc.nextInt();
		   
		  switch(opt) {
		  case 1:
			 
			  System.out.println("Enter Customer name: ");
			  String name = sc.next();
			  System.out.println("Enter Customer Address: ");
			  name = sc.next();
			  System.out.println("Enter Aadhar Card Number: ");
			  double aadharCard = sc.nextDouble();
			  System.out.println("Enter phone Number: ");
			  long phoneNumber = sc.nextLong();
		
			  Account a = new Account();
			  a.setName(name);
			  a.setInitialBalance(1000);
			  a.setPhoneNumber(phoneNumber);
			  a.setAccountNumber(phoneNumber);
			  a.setAadharCard(aadharCard);
			  Transaction t = new Transaction();
				t.setAmount(1000);
				t.setType("Opening Balance");
				t.setDate(LocalDateTime.now());
				t.setBalance(1000);
				a.setTransactions(t);
			  ips.addAccount(a);
			  break;
			  
		  case 2:
			  System.out.println("Enter acc no to show Balance");
			  long accountNumber = sc.nextLong();
			  ips.showBalance(accountNumber);
			  break;
		  
		  case 3:
			  System.out.println("Enter acc no to deposit into");
			  accountNumber = sc.nextLong();
			  System.out.println("Enter amount to deposit");
			  double amount = sc.nextDouble();
		      ips.deposit(accountNumber, amount);
		      break;
		  
		  case 4:
			  System.out.println("Enter acc no to withdraw from");
			  accountNumber = sc.nextLong();
			  System.out.println("Enter amount to withdraw");
			  amount = sc.nextDouble();
		      ips.withdraw(accountNumber, amount);
		  break;
		  
		  case 5:
			  System.out.println("Enter account no to print transactions");
			  accountNumber = sc.nextLong();
			  ips.showTransactions(accountNumber);
		  break;
		  
		  case 6:
			  System.out.println("Enter your account no and amount ");
			  accountNumber = sc.nextLong();
			  amount = sc.nextDouble();
			  System.out.println("Enter acc no to transfer into ");
			  long accountNumber2 = sc.nextLong();
			  ips.fundTransfer(accountNumber,accountNumber2,amount);
			  break;
			  
		  case 7:
			  System.out.println("Come Back Soon");
			  sc.close();
			  System.exit(0);
		  }
		}	
		
	}
}
