package com.cg.PaymentWalletApplication.service;

import com.cg.PaymentWalletApplication.bean.Account;
import com.cg.PaymentWalletApplication.dao.AccountRepoImpl;
import com.cg.PaymentWalletApplication.dao.IAccountRepo;

public class AccountServiceImpl implements IAccountService {

	IAccountRepo ips = new AccountRepoImpl();
	
	@Override
	public void addAccount(Account a) {
		ips.addAccount(a);

	}

	@Override
	public void showBalance(long accountNumber) {
		ips.showBalance(accountNumber);

	}

	@Override
	public void deposit(long accountNumber, double amount) {
		ips.deposit(accountNumber, amount);

	}

	@Override
	public void withdraw(long accountNumber, double amount) {
		ips.withdraw(accountNumber, amount);

	}
	@Override
	public void fundTransfer(long accountNumber, long accountNumber2,double amount) {
		ips.fundTransfer(accountNumber, accountNumber2, amount);
		
	}

	@Override
	public void showTransactions(long accountNumber) {
		ips.showTransactions(accountNumber);

	}
	
	
}
