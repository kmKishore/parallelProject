package com.cg.PaymentWalletApplication.exception;

public class PaymentWalletException extends Exception {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public PaymentWalletException(String msg) {
		// TODO Auto-generated constructor stub
		super(msg);
	}

}
