package com.cg.PaymentWalletApplication.ui;

import java.sql.SQLException;
import java.util.Scanner;

import com.cg.PaymentWalletApplication.bean.Account;
import com.cg.PaymentWalletApplication.exception.PaymentWalletException;
import com.cg.PaymentWalletApplication.service.AccountServiceImpl;
import com.cg.PaymentWalletApplication.service.IAccountService;

public class BankClient {
	IAccountService iad = new AccountServiceImpl();
	Scanner sc = new Scanner(System.in);

	void menu() throws ClassNotFoundException, SQLException {

		while (true) {
			System.out.println(
					"\n1. Create Account\n2. Show Balance\n3. Deposit\n4. Withdraw\n5. Print Transactions\n6. Fund Transfer\n7. Exit :)");
			switch (sc.next()) {
			case "1":
				Account a = new Account();
				
				String name;
				do {
					System.out.println("Enter name: ");
					name = sc.next();
				} while (!iad.accountHolderValidation(name));
				a.setAccountHolder(name);

				String mail;
				do {
					System.out.println("Enter mail: ");
					mail = sc.next();
				} while (!iad.mailValidation(mail));
				a.setEmail(mail);

				System.out.println("Enter city: ");
				a.setAddress(sc.next());

				long mobNum;
				do {
					System.out.println("Enter mobile number: ");
					mobNum = sc.nextLong();
				} while (!iad.mobValidation(mobNum));
				a.setMobileNumber(mobNum);
				
				a.setBalance(0);
				long accNum = 0L;
				try {
					accNum = iad.addAccount(a);
				} catch (PaymentWalletException e) {
					// TODO Auto-generated catch block
					System.err.println(e.getMessage());
				}
				System.out.println("Congratulations! Your account has been successfully opened in XYZ Bank");
				System.out.println(
						"For our new customers we are giving 500 rupees bonus which has been added to your account.");
				System.out.println("Account Number: " + accNum);
				break;
			case "2":
				
				long accountNumber;
				do {
					System.out.println("Enter your account No: ");
					accountNumber = sc.nextLong();
				} while (!iad.accountNumberValidation(accountNumber));
				
				try {
					System.out.println("Your balance: " + iad.showBalance(accountNumber));
				} catch (PaymentWalletException e) {
					// TODO Auto-generated catch block
					System.err.println(e.getMessage());
				}
				break;
			case "3":
				long accountNumber1;
				do {
					System.out.println("Enter your account No: ");
					accountNumber1 = sc.nextLong();
				} while (!iad.accountNumberValidation(accountNumber1));
				
				double balance;
				do {
					System.out.println("Enter amount: ");
					balance = sc.nextDouble();
				} while (!iad.balanceValidation(balance));
				
				try {
					if (iad.deposit(accountNumber1, balance))
						System.out.println("Deposited successfully!!!");
					else
						System.out.println("Failed!!!");
				} catch (PaymentWalletException e) {
					System.err.println(e.getMessage());
				}
				break;
			case "4":
				long accountNumber5;
				do {
					System.out.println("Enter your account No: ");
					accountNumber5 = sc.nextLong();
				} while (!iad.accountNumberValidation(accountNumber5));
				
				double balance1;
				do {
					System.out.println("Enter amount: ");
					balance1 = sc.nextDouble();
				} while (!iad.balanceValidation(balance1));
				
				try {
					if (iad.withdraw(accountNumber5, balance1))
						System.out.println(" successfully!!!");
					else
						System.out.println("Failed!!!");
				} catch (PaymentWalletException e) {
					// TODO Auto-generated catch block
					System.err.println(e.getMessage());
				}
				break;
			case "5":
				long accountNumber2;
				do {
					System.out.println("Enter your account No: ");
					accountNumber2 = sc.nextLong();
				} while (!iad.accountNumberValidation(accountNumber2));
				try {
					System.out.println(iad.printTransactions(accountNumber2));
				} catch (PaymentWalletException e) {
					System.err.println(e.getMessage());
				}
				break;
			case "6":
				long accountNumber3;
				do {
					System.out.println("Enter your account No: ");
					accountNumber3 = sc.nextLong();
				} while (!iad.accountNumberValidation(accountNumber3));
				
				double am;
				do {
					System.out.println("Enter amount: ");
					am = sc.nextDouble();
				} while (!iad.balanceValidation(am));

				try {
					long accountNumber4;
					do {
						System.out.println("Account number where you want to transfer: ");
						accountNumber4 = sc.nextLong();
					} while (!iad.accountNumberValidation(accountNumber4));
					
					if(iad.fundTransfer(accountNumber3, accountNumber4, am))
						System.out.println("successful!!!");
					else System.out.println("failed!!!!");
				} catch (PaymentWalletException e) {
					// TODO Auto-generated catch block
					System.err.println(e.getMessage());
				}
				break;
			case "7":
				System.out.println("Terminaed!!!!");
				sc.close();
				System.exit(0);
			default:
				System.err.println("Wrong input !!!!");
			}
		}
	}

	public static void main(String[] args) throws ClassNotFoundException, SQLException {
		BankClient tb = new BankClient();
		tb.menu();
	}
}
