package com.cg.PaymentWalletApplication.dao;

import java.sql.SQLException;
import java.util.List;

import com.cg.PaymentWalletApplication.bean.Account;
import com.cg.PaymentWalletApplication.bean.Transaction;
import com.cg.PaymentWalletApplication.exception.PaymentWalletException;

public interface IAccountRepo {
	long addAccount(Account a) throws PaymentWalletException;
	double showBalance(long accountNumber) throws PaymentWalletException;
	boolean deposit(long accountNumber, double amount) throws PaymentWalletException;
	boolean withdraw(long accountNumber, double amount) throws PaymentWalletException;
	boolean fundTransfer(long accountNumber, long accountNumber2, double amount) throws PaymentWalletException;
	List<Transaction> printTransactions(long accountNumber) throws PaymentWalletException;
}
