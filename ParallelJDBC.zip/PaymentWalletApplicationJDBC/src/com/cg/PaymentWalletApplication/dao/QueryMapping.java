package com.cg.PaymentWalletApplication.dao;

public interface QueryMapping {

	public static final String INSERT_QUERY="INSERT INTO accounts VALUES(accnumber.nextval, ?, ?, ?, ?, ?)";
	public static final String SEQ_CURR_VAL="SELECT accnumber.currval FROM dual";
	//public static final String SELECT_QUERY="SELECT * FROM accounts";
	public static final String SELECT_BALANCE_QUERY="SELECT balance FROM accounts WHERE accountNumber=?";
	public static final String UPDATE_QUERY="UPDATE accounts SET balance=? WHERE accountNumber=?";
	public static final String INSERT_TRANSACTION="INSERT INTO transactions VALUES(?, ?, ?, ?, ?)";
	public static final String SELECT_TRANSACTION="SELECT * FROM transactions WHERE accountNumber=?";
}
