package com.cg.PaymentWalletApplication.dao;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

import com.cg.PaymentWalletApplication.bean.Account;
import com.cg.PaymentWalletApplication.bean.Transaction;
import com.cg.PaymentWalletApplication.exception.PaymentWalletException;
import com.cg.PaymentWalletApplication.util.ConnectionFactory;

public class AccountRepoImpl implements IAccountRepo {

	Connection con = null;
	PreparedStatement ps = null;

	@Override
	public long addAccount(Account a) throws PaymentWalletException {

		try {
			con = ConnectionFactory.getSigtonObj().getConnection();
		} catch (PaymentWalletException e) {
			// TODO Auto-generated catch block
			throw new PaymentWalletException("connection issues!");
		}
		long accountNumber = 0;
		try {
			ps = con.prepareStatement(QueryMapping.INSERT_QUERY);
			// ps.setString(1, "");
			ps.setString(1, a.getAccountHolder());
			ps.setString(2, a.getAddress());
			ps.setLong(3, a.getMobileNumber());
			ps.setDouble(4, a.getBalance());
			ps.setString(5, a.getEmail());

			ps.executeUpdate();

			ps = con.prepareStatement(QueryMapping.SEQ_CURR_VAL);
			ResultSet rs = ps.executeQuery();
			rs.next();
			accountNumber = rs.getLong(1);
			deposit(accountNumber, 500);
		} catch (Exception e) {
			throw new PaymentWalletException("coudn't run query. " + e.getMessage());
		} finally {
			try {
				if (con != null)
					con.close();
				if (ps != null)
					ps.close();
			} catch (Exception e) {
				throw new PaymentWalletException("problem in connection closing!!!!"+e.getMessage());
			}
		}

		return accountNumber;
	}

	@Override
	public double showBalance(long accountNumber) throws PaymentWalletException {
		// TODO Auto-generated method stub
		// System.out.println(bank.get(accountNumber).getBalance());
		ResultSet rs = null;
		double balance;
		try {
			con = ConnectionFactory.getSigtonObj().getConnection();
		} catch (PaymentWalletException e) {
			// TODO Auto-generated catch block
			throw new PaymentWalletException("connection couldn't be established!!!");
		}
		try {
			ps = con.prepareStatement(QueryMapping.SELECT_BALANCE_QUERY);
			ps.setLong(1, accountNumber);
			rs = ps.executeQuery();
			if(rs.next())
				balance = rs.getDouble(1);
			else {
				if (con != null)
					con.close();
				if (ps != null)
					ps.close();
				throw new PaymentWalletException("account number is not present!!!!");
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			throw new PaymentWalletException("couldn't execute query!!!");
		} finally {
			try {
				if (con != null)
					con.close();
				if (ps != null)
					ps.close();
				if (rs != null)
					rs.close();
			} catch (Exception e) {
				throw new PaymentWalletException("problem in connection closing!!!!");
			}
		}
		return balance;
	}

	@Override
	public boolean deposit(long accountNumber, double amount) throws PaymentWalletException {
		ResultSet rs = null;
		double balance = 0;
		try {
			con = ConnectionFactory.getSigtonObj().getConnection();
		} catch (PaymentWalletException e) {
			// TODO Auto-generated catch block
			throw new PaymentWalletException("connection couldn't be established!!!");
		}
		try {
			ps = con.prepareStatement(QueryMapping.SELECT_BALANCE_QUERY);
			ps.setLong(1, accountNumber);
			rs = ps.executeQuery();
			ps = con.prepareStatement(QueryMapping.UPDATE_QUERY);
			if (rs.next())
				balance = rs.getDouble(1) + amount;
			else {
				con.close();
				ps.close();
				rs.close();
				throw new PaymentWalletException("account number is not present!!!!");
			}
			ps.setDouble(1, balance);
			ps.setLong(2, accountNumber);
			ps.executeUpdate();
			System.out.println("------------------------------------------------");
			System.out.println("Done!!!!");
			System.out.println("------------------------------------------------");
		} catch (Exception e) {
			throw new PaymentWalletException("couldn't execute query!!!");
		} finally {
			try {
				if (con != null)
					con.close();
				if (ps != null)
					ps.close();
				if (rs != null)
					rs.close();
			} catch (Exception e) {
				throw new PaymentWalletException("problem in connection closing!!!!");
			}
		}

		putTransaction(amount, accountNumber, "Credited", balance);
		return true;
	}

	@Override
	public boolean withdraw(long accountNumber, double amount) throws PaymentWalletException {
		ResultSet rs = null;
		try {
			con = ConnectionFactory.getSigtonObj().getConnection();
		} catch (PaymentWalletException e) {
			// TODO Auto-generated catch block
			throw new PaymentWalletException("connection couldn't be stablished!!!");
		}
		try {
			ps = con.prepareStatement(QueryMapping.SELECT_BALANCE_QUERY);
			ps.setLong(1, accountNumber);
			rs = ps.executeQuery();
			ps = con.prepareStatement(QueryMapping.UPDATE_QUERY);
			double balance;
			if (rs.next())
				balance = rs.getDouble(1) - amount;
			else {
				con.close();
				ps.close();
				rs.close();
				throw new PaymentWalletException("account number is not present!!!!");
			}
			ps.setDouble(1, balance);
			ps.setLong(2, accountNumber);
			ps.executeUpdate();
			System.out.println("------------------------------------------------");
			System.out.println("Done!!!!");
			System.out.println("------------------------------------------------");
			putTransaction(amount, accountNumber, "Debited", balance);
			return true;
		} catch (Exception e) {
			throw new PaymentWalletException("couldn't execute query!!! "+e.getMessage());
		} finally {
			try {
				if (con != null)
					con.close();
				if (ps != null)
					ps.close();
				if (rs != null)
					rs.close();
			} catch (Exception e) {
				throw new PaymentWalletException("problem in connection closing!!!!");
			}
		}
	}

	void putTransaction(double amount, long acc, String msg, double bal) throws PaymentWalletException {

		try {
			con = ConnectionFactory.getSigtonObj().getConnection();
		} catch (PaymentWalletException e) {
			// TODO Auto-generated catch block
			throw new PaymentWalletException("connection couldn't be established!!!");
		}
		try {
			ps = con.prepareStatement(QueryMapping.INSERT_TRANSACTION);
			ps.setLong(1, acc);
			ps.setDouble(2, amount);
			ps.setString(3, msg);
			ps.setDate(4, Date.valueOf(java.time.LocalDate.now()));
			ps.setDouble(5, bal);

			ps.executeUpdate();
		} catch (Exception e) {
			throw new PaymentWalletException("couldn't execute query!!!");
		} finally {
			try {
				if (con != null)
					con.close();
				if (ps != null)
					ps.close();
			} catch (Exception e) {
				throw new PaymentWalletException("problem in connection closing!!!!");
			}
		}
	}

	@Override
	public boolean fundTransfer(long accountNumber, long accountNumber2, double amount) throws PaymentWalletException {
		// TODO Auto-generated method stub
		if(withdraw(accountNumber, amount) && deposit(accountNumber2, amount))
			return true;
		return false;
	}

	@Override
	public List<Transaction> printTransactions(long accountNumber) throws PaymentWalletException {
		try {
			con = ConnectionFactory.getSigtonObj().getConnection();
		} catch (PaymentWalletException e) {
			// TODO Auto-generated catch block
			throw new PaymentWalletException("connection couldn't be established!!!");
		}
		try {
			ps = con.prepareStatement(QueryMapping.SELECT_TRANSACTION);
			ps.setLong(1, accountNumber);
			ResultSet rs = ps.executeQuery();
			List<Transaction> transactions = new ArrayList<Transaction>();
			while (rs.next()) {
				Transaction transaction = new Transaction();
				transaction.setDate(rs.getDate(4).toLocalDate());
				transaction.setAmount(rs.getDouble(2));
				transaction.setType(rs.getString(3));
				transaction.setBalance(rs.getDouble(5));
				transactions.add(transaction);
			}
			System.out.println("------------------------------------------------");
			return transactions;
		} catch (Exception e) {
			throw new PaymentWalletException("couldn't execute query!!!");
		} finally {
			try {
				if (con != null)
					con.close();
				if (ps != null)
					ps.close();
			} catch (Exception e) {
				throw new PaymentWalletException("problem in connection closing!!!!");
			}
		}
	}

}
