package com.cg.PaymentWalletApplication.test;

import static org.junit.Assert.*;

import org.junit.Test;

import com.cg.PaymentWalletApplication.service.AccountServiceImpl;
import com.cg.PaymentWalletApplication.service.IAccountService;

public class TestMailValidation {

	IAccountService service = new AccountServiceImpl();
	
	@Test
	public void testRightMail() {
		String mail = "a@gmail.com";
		assertTrue(service.mailValidation(mail));
	}
	
	@Test // start with number
	public void testRightMail2() {
		String mail = "123@gmail.com";
		assertTrue(service.mailValidation(mail));
	}
	
	@Test // not minimum character before '@'
	public void testWrongMail() {
		String mail = "@gmail.com";
		assertFalse(service.mailValidation(mail));
	}
	
	@Test // no '@' 
	public void testWrongMail2() {
		String mail = "agmail.com";
		assertFalse(service.mailValidation(mail));
	}
	
	@Test // without (.) dot 
	public void testWrongMail3() {
		String mail = "a@gmailcom";
		assertFalse(service.mailValidation(mail));
	}
}
