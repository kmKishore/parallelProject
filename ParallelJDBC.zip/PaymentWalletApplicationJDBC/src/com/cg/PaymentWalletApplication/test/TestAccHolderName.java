package com.cg.PaymentWalletApplication.test;

import static org.junit.Assert.*;

import org.junit.Test;

import com.cg.PaymentWalletApplication.service.AccountServiceImpl;
import com.cg.PaymentWalletApplication.service.IAccountService;

public class TestAccHolderName {

	IAccountService service = new AccountServiceImpl();
	
	@Test
	public void test1() {
		//fail("Not yet implemented");
		String name = "kishore";
		assertFalse(service.accountHolderValidation(name));
	}
	
	@Test
	public void test2() {
		//fail("Not yet implemented");
		String name = "Kishore";
		assertTrue(service.accountHolderValidation(name));
	}
	
	@Test
	public void test3() {
		//fail("Not yet implemented");
		String name = "Kishore1";
		assertFalse(service.accountHolderValidation(name));
	}
	
	@Test
	public void test4() {
		//fail("Not yet implemented");
		String name = "1234";
		assertFalse(service.accountHolderValidation(name));
	}
	
	@Test
	public void test5() {
		//fail("Not yet implemented");
		String name = "Abc";
		assertFalse(service.accountHolderValidation(name));
	}
	
	@Test
	public void test6() {
		//fail("Not yet implemented");
		String name = "abcdfdasdfsdafasdf";
		assertFalse(service.accountHolderValidation(name));
	}
	
	@Test
	public void test7() {
		//fail("Not yet implemented");
		String name = null;
		assertFalse(service.accountHolderValidation(name));
	}
}
