package com.cg.PaymentWalletApplication.test;

import static org.junit.Assert.*;

import org.junit.Test;

import com.cg.PaymentWalletApplication.dao.AccountRepoImpl;
import com.cg.PaymentWalletApplication.dao.IAccountRepo;
import com.cg.PaymentWalletApplication.exception.PaymentWalletException;

public class TestShowBalance {

	IAccountRepo dao = new AccountRepoImpl(); 
	
	@Test(expected=PaymentWalletException.class)
	public void test() throws PaymentWalletException {
			assertEquals(0, dao.showBalance(123456), 1);
	}
	
	@Test
	public void test2() throws PaymentWalletException {
			assertEquals(2000, dao.showBalance(10000), 1);
	}
}
