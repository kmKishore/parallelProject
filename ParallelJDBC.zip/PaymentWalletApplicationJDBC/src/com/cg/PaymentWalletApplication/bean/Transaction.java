package com.cg.PaymentWalletApplication.bean;

import java.time.LocalDate;

public class Transaction {
	private double amount;
	private String type; // debit or credit
	private LocalDate date;
	private double balance;
	
	public double getAmount() {
		return amount;
	}
	public void setAmount(double amount) {
		this.amount = amount;
	}
	public String getType() {
		return type;
	}
	public void setType(String type) {
		this.type = type;
	}
	public LocalDate getDate() {
		return date;
	}
	public void setDate(LocalDate localDate) {
		this.date = localDate;
	}
	
	public double getBalance() {
		return balance;
	}
	public void setBalance(double balance) {
		this.balance = balance;
	}
	@Override
	public String toString() {
		return "Transaction [amount=" + amount + ", type=" + type + ", date="
				+ date + ", balance=" + balance + "]\n";
	}
	
}
