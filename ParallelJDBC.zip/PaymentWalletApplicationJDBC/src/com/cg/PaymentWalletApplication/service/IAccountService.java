package com.cg.PaymentWalletApplication.service;

import java.util.List;

import com.cg.PaymentWalletApplication.bean.Account;
import com.cg.PaymentWalletApplication.bean.Transaction;
import com.cg.PaymentWalletApplication.exception.PaymentWalletException;

public interface IAccountService {
	long addAccount(Account a) throws PaymentWalletException;
	double showBalance(long accountNumber) throws PaymentWalletException;
	boolean deposit(long accountNumber, double amount) throws PaymentWalletException;
	boolean withdraw(long accountNumber, double amount) throws PaymentWalletException;
	boolean fundTransfer(long accountNumber, long accountNumber2, double amount) throws PaymentWalletException;
	List<Transaction> printTransactions(long accountNumber) throws PaymentWalletException;
	
	
	boolean mailValidation (String mail);
	boolean mobValidation(long mobileNumber);
	boolean accountHolderValidation(String accountHolder);
	boolean balanceValidation(double balance);
	boolean accountNumberValidation(long accountNumber);
}
