package com.cg.PaymentWalletApplication.service;

import java.util.List;

import com.cg.PaymentWalletApplication.bean.Account;
import com.cg.PaymentWalletApplication.bean.Transaction;
import com.cg.PaymentWalletApplication.dao.AccountRepoImpl;
import com.cg.PaymentWalletApplication.dao.IAccountRepo;
import com.cg.PaymentWalletApplication.exception.PaymentWalletException;

public class AccountServiceImpl implements IAccountService {
	
	IAccountRepo iap = new AccountRepoImpl();

	@Override
	public long addAccount(Account a) throws PaymentWalletException{
		// TODO Auto-generated method stub
		try {
			return iap.addAccount(a);
		} catch (PaymentWalletException e) {
			// TODO Auto-generated catch block
			throw new PaymentWalletException(e.getMessage());
		}
	}

	@Override
	public double showBalance(long accountNumber) throws PaymentWalletException {
		// TODO Auto-generated method stub
		return iap.showBalance(accountNumber);
	}

	@Override
	public boolean deposit(long accountNumber, double amount) throws  PaymentWalletException{
		// TODO Auto-generated method stub
		return iap.deposit(accountNumber, amount);
	}

	@Override
	public boolean withdraw(long accountNumber, double amount) throws PaymentWalletException {
		// TODO Auto-generated method stub
		return iap.withdraw(accountNumber, amount);
	}

	@Override
	public boolean fundTransfer(long accountNumber, long accountNumber2, double amount) throws  PaymentWalletException{
		// TODO Auto-generated method stub
		return iap.fundTransfer(accountNumber, accountNumber2, amount);
	}

	@Override
	public List<Transaction> printTransactions(long accountNumber) throws  PaymentWalletException{
		// TODO Auto-generated method stub
		return iap.printTransactions(accountNumber);
	}
	
	@Override
	public boolean mailValidation (String mail){
		String regex = "[a-zA-Z0-9]+[@][a-zA-Z0-9]+([.][a-zA-Z]+)+";
		return mail.matches(regex);
	}
	
	@Override
	public boolean mobValidation(long mobileNumber){
		String regex = "(91|0)?[6-9][0-9]{9}";
		String sNum = Long.toString(mobileNumber);
		return sNum.matches(regex);
	}
	
	@Override
	public boolean accountHolderValidation(String accountHolder) {
		String regex = "[A-Z][a-z]{3,15}";
		if(accountHolder == null)
			return false;
		
		return accountHolder.matches(regex);
	}
	
	@Override
	public boolean balanceValidation(double balance) {
		String regex = "[0-9]*\\.?[0-9]*";
		String bal = Double.toString(balance);
		//System.out.println(bal);
		return bal.matches(regex);
	}
	
	@Override
	public boolean accountNumberValidation(long mobileNumber){
		String regex = "[0-9]{4,10}";
		String sNum = Long.toString(mobileNumber);
		return sNum.matches(regex);
	}
	
}
